$(document).ready(function() {
        $('#js-basic-example').dataTable();
} );