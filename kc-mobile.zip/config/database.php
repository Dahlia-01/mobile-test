<?php

define('DB_TYPE', 'mysqli');
define('DB_HOST', 'MYSQL5011.SmarterASP.NET');
define('DB_NAME', 'db_a11d64_care');
define('DB_USER', 'a11d64_care');
define('DB_PASS', 'db_a11d64_care');