
    <!-- Jquery Core Js -->
    <script src="public/admin/plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="public/admin/plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
<!--     <script src="public/admin/plugins/bootstrap-select/js/bootstrap-select.js"></script>  -->

    <!-- Jquery Validation Plugin Css -->
    <script src="public/admin/plugins/jquery-validation/jquery.validate.js"></script>

    <!-- JQuery Steps Plugin Js -->
    <script src="public/admin/plugins/jquery-steps/jquery.steps.js"></script>

    <!-- Sweet Alert Plugin Js -->
    <script src="public/admin/plugins/sweetalert/sweetalert.min.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="public/admin/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="public/admin/plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="public/admin/plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="public/admin/plugins/raphael/raphael.min.js"></script>
    <script src="public/admin/plugins/morrisjs/morris.js"></script> 

    <!-- Multi Select Plugin Js -->
    <script src="public/admin/plugins/multi-select/js/jquery.multi-select.js"></script>

    <!-- Jquery Spinner Plugin Js -->
    <script src="public/admin/plugins/jquery-spinner/js/jquery.spinner.js"></script>

    <!-- Bootstrap Tags Input Plugin Js -->
    <script src="public/admin/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>

    <!-- noUISlider Plugin Js -->
    <script src="public/admin/plugins/nouislider/nouislider.js"></script>

    <!-- Dropzone Plugin Js -->
    <script src="public/admin/plugins/dropzone/dropzone.js"></script>

    <!-- Input Mask Plugin Js -->
    <script src="public/admin/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>

    <!-- ChartJs -->
    <script src="public/admin/plugins/chartjs/Chart.bundle.js"></script> 

    <!-- Autosize Plugin Js -->
    <script src="public/admin/plugins/autosize/autosize.js"></script> 

    <!-- Moment Plugin Js -->
    <script src="public/admin/plugins/momentjs/moment.js"></script> 

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="public/admin/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Colorpicker Js -->
    <script src="public/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>

    <script src="public/admin/js/pages/ui/modals.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="public/admin/plugins/jquery-sparkline/jquery.sparkline.js"></script>
<!--     <script type="text/javascript" src="public/js/awesomplete.js"></script> -->

    <!-- Jquery DataTable Plugin Js -->
    <script src="public/admin/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="public/admin/plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

 <!-- Jquery DataTable Plugin Js -->
    <script src="public/jquery-datatable/jquery.dataTables.js"></script>
    <script src="public/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="public/js/jquery-datatable.js"></script>

    <!-- Custom Js -->
    <script src="public/admin/js/admin.js"></script>
    <script src="public/admin/js/pages/forms/basic-form-elements.js"></script>
    <script src="public/admin/js/pages/forms/advanced-form-elements.js"></script>
    <script src="public/admin/js/pages/index.js"></script>

    <!-- Demo Js -->
    <script src="public/admin/js/demo.js"></script>
</body>

</html>