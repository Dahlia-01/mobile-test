<?php

define ('URL', '/');

?>